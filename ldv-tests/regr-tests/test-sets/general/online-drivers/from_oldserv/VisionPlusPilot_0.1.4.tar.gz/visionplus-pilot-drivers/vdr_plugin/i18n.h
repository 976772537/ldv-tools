
const tI18nPhrase Phrases[] = {
  { "Vision Plus 1022A IR port control for vdr",// English
    "",// Deutsch
    "",// Slovenski
    "",// Italiano
    "",// Nederlands
    "",// Portugu�s
    "",// Fran�ais
    "",// Norsk
    "",// suomi
    "Kontroler pilota Vision Plus dla VDR",// Polski
    "",// Espa�ol
    "",// ��������
    "",// Svenska
    "",// Romaneste
    "",// Magyar
    "",// Catal�
  },
  { "(re)open IR port device",
    "",// Deutsch
    "",// Slovenski
    "",// Italiano
    "",// Nederland
    "",// Portugu�s
    "",// Fran�ais
    "",// Norsk
    "",// suomi
    "Otw�rz (ponownie) plik urz�dzenia",
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
  },
  { "(re)opening device ...",
    "",// Deutsch
    "",// Slovenski
    "",// Italiano
    "",// Nederland
    "",// Portugu�s
    "",// Fran�ais
    "",// Norsk
    "",// suomi
    "otwieram urz�dzenie",
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
  },
  { "Success ;-)",
    "",// Deutsch
    "",// Slovenski
    "",// Italiano
    "",// Nederland
    "",// Portugu�s
    "",// Fran�ais
    "",// Norsk
    "",// suomi
    "Sukces ;-)",
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
  },
  { "Error opening IR port device!",
    "",// Deutsch
    "",// Slovenski
    "",// Italiano
    "",// Nederland
    "",// Portugu�s
    "",// Fran�ais
    "",// Norsk
    "",// suomi
    "B��d podczas otwierania pliku urz�dzenia",
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
  },
  { "Unknown ERROR!",
    "",// Deutsch
    "",// Slovenski
    "",// Italiano
    "",// Nederland
    "",// Portugu�s
    "",// Fran�ais
    "",// Norsk
    "",// suomi
    "Nieznany b�ad",
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
    "",// TODO
  },
  { NULL }
  };

