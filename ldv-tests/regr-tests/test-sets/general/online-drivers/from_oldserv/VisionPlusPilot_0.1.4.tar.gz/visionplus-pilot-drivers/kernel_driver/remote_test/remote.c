/*

	copyright (c) 2006 Andrzej Oczkowicz <andrew_lz@poczta.fm>

*/



#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "vp_remote.h"


int main(int argc, char* argv[])
{
	#define REMAP(idx, val)		if ( !vp_remap(dev, (idx), (val) ) ) \
						printf("Error vp_remap()\n");
	#define CMD(val)		if ( !vp_sendcmd(dev, (val) ) ) \
						printf("Error vp_sendcmd()\n");

	printf("Vision Plus Pilot test program\nPress POWER button to exit...\n");

	int dev = open(REMOTE_DEV, OPEN_FLAGS); 
	if ( dev != -1 ) {
		CMD(CMD_REMAP_ON);
		CMD(CMD_EVENTS_OFF);
		
		REMAP(KEY_FULLSCREEN, 33)	

		while ( 1 ) {
			unsigned char cmd = 0;
			int retval = read(dev, &cmd, 1);
			if ( retval && cmd ) {
				printf("read key: %d [%c]\n", cmd, cmd);
				if ( cmd == 64 ){
					printf("\nPower button pressed.\nExiting...\n");
					break;
				}
			} else {
				usleep( REF_TIME * 1000 );
			}
		}
	} else {
		printf("error opening: '"REMOTE_DEV"' !\n");
		return 1;
	}
	close(dev);
	return 0;
}


