#!/bin/bash
#
#	Vision Plus 1022A Remote Control Command Script
#
#
#

case "$1" in
 KEY_FULLSCREEN) echo "Co checesz fuulscreen" ;;
 KEY_POWER) echo "exit??" ;;
 KEY_0)  ;;
 KEY_1)  ;;
 KEY_2)  ;;
 KEY_3)  ;;
 KEY_4)  ;;
 KEY_5)  ;;
 KEY_6)  ;;
 KEY_7)  ;;
 KEY_8)  ;;
 KEY_9)  ;;
 KEY_REC)  ;;
 KEY_FAVORITE)  ;;
 KEY_REWIND)  ;;
 KEY_FORWARD)  ;;
 KEY_UP)  ;;
 KEY_DOWN)  ;;
 KEY_LEFT)  ;;
 KEY_RIGHT)  ;;
 KEY_PLAY)  ;;
 KEY_STOP)  ;;
 KEY_RECALL)  ;;
 KEY_PAUSE)  ;;
 KEY_MUTE)  ;;
 KEY_CANCEL)  ;;
 KEY_CAPTURE)  ;;
 KEY_PREVIEW)  ;;
 KEY_EPG)  ;;
 KEY_RECORDS)  ;;
 KEY_TAB)  ;;
 KEY_TELETEXT)  ;;
  *)
	echo "Unknown option $1 !"
esac