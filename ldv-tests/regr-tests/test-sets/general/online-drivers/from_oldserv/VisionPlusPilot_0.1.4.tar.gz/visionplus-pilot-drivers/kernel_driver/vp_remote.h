/***************************************************************************
 *   Copyright (C) 2005 by Andrzej Oczkowicz                               *
 *   andrew_lz@poczta.fm amg.linuxpl.com                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
 

//version 0.1.2

 
 
#ifndef _VP_REMOTE_H
#define _VP_REMOTE_H

  

/* device commands */
#define CMD_DBG_ON		0	
#define CMD_DBG_OFF		1
#define CMD_REMAP_ON		2
#define CMD_REMAP_OFF		3
#define CMD_EVENTS_ON		4
#define CMD_EVENTS_OFF		5

#define CMD_PRINT_INFO		6
#define CMD_RAISE_EVENT		7

#define CMD_CLEAR_TABLE		8
#define CMD_LOCK_DEVICE		9
#define CMD_UNLOCK_DEVICE	10


#ifndef _VP_KERNEL_MODULE_

#include <stdio.h> 
#include <fcntl.h>

 /* remote control key kodes */ 
#define KEY_FULLSCREEN		44

/* 42, 56, 64, 29 */	
#define KEY_POWER		64
#define KEY_POWER0		42
#define KEY_POWER1		56
#define KEY_POWER2		29
		
#define KEY_0			11	
#define KEY_1			2
#define KEY_2			3
#define KEY_3			4
#define KEY_4			5
#define KEY_5			6
#define KEY_6			7
#define KEY_7			8
#define KEY_8			9
#define KEY_9			10	

#define KEY_REC			102
#define KEY_FAVORITE		47
	
#define KEY_REWIND		23
#define KEY_FORWARD		49
	
#define KEY_UP			104
#define KEY_DOWN		109
/* 42 & 108 */
#define KEY_LEFT		108
#define KEY_LEFT0		42

/* 42 & 103 */
#define KEY_RIGHT		103
#define KEY_RIGHT0		42
	
#define KEY_PLAY		28
#define KEY_STOP		107
#define KEY_RECALL		46
#define KEY_PAUSE		20
#define KEY_MUTE		50
#define KEY_CANCEL		1
#define KEY_CAPTURE		25
#define KEY_PREVIEW		37
#define KEY_EPG			18
#define KEY_RECORDS		38
#define KEY_TAB			15
#define KEY_TELETEXT		30



#define REMOTE_DEV		"/dev/vp_remote" 
#define REF_TIME		100 /* msec */
#define OPEN_FLAGS		O_SYNC | O_RDWR 


/* send cmd to driver, return zero on error */
int vp_sendcmd(int file, int cmd)
{
	if ( file ) {
		unsigned char cmds[3];
		cmds[0] = 0;
		cmds[1] = 0;
		cmds[2] = cmd;
		int retval = write(file, &cmds, sizeof(cmds));
		fsync(file);
		return retval == sizeof(cmds);
	} else return 0;
}

/* raise keyboard event send CMD_EVENTS_ON command first, return zero on error */
int vp_event(int file, int key)
{
	if ( file ) {
		unsigned char cmds[4];
		cmds[0] = 0;
		cmds[1] = 0;
		cmds[2] = CMD_RAISE_EVENT;
		cmds[3] = key;
		int retval = write(file, &cmds, sizeof(cmds));
		fsync(file);
		return retval == sizeof(cmds);
	} else return 0;
}

/* remap char at idx to val, return zero at error */
int vp_remap(int file, int idx, int val)
{
	if ( file ) {
		unsigned char remaps[2];
		remaps[0] = idx;
		remaps[1] = val;
		int retval = write(file, &remaps, sizeof(remaps));
		fsync(file);
		return retval == sizeof(remaps);
	} else return 0;

}

#endif

#endif //_VP_REMOTE_H
