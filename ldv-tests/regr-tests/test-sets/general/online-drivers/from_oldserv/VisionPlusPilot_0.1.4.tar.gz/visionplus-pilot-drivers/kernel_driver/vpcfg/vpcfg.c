/***************************************************************************
 *   Copyright (C) 2005 by Andrzej Oczkowicz                               *
 *   andrew_lz@poczta.fm                                                   *
 *   amg.thc.net.pl                                                        *
 *                                                                         *
 *                                                                         * 
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
 
 /*
 
 	Vision Plus Remote Config
 
 */
 
 
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/wait.h> 
#include <signal.h>
#include "vp_remote.h"

#define VERSION	"0.1.2"
#define INFO "Copyright (c) Andrzej Oczkowicz 2006 ver: "VERSION

typedef struct 
{
	int code;
	char *text;
} opt;

char *cmds[] = {
				 "CMD_DBG_ON",
				 "CMD_DBG_OFF",
				 "CMD_REMAP_ON",
				 "CMD_REMAP_OFF",
				 "CMD_EVENTS_ON",
				 "CMD_EVENTS_OFF",
				 "CMD_PRINT_INFO",
				 "CMD_RAISE_EVENT",
				 "CMD_CLEAR_TABLE",
				 "CMD_LOCK_DEVICE",
				 "CMD_UNLOCK_DEVICE",
				NULL
};

int arg_num(int argc, char *argv[], char *arg_name)
{
  int i;
  for ( i=1; i < argc; i++){
       if ( !strcasecmp(argv[i], arg_name) )
       		return i;
  } 
  return 0;
}

int cmd_idx(char *cmd)
{
	int i;
	for (i=0; cmds[i]; i++){
		if (strcmp(cmd, cmds[i])==0)
			return i;
	}
	return -1;
}

int main(int argc, char *argv[])
{

	if ( arg_num(argc, argv, "--help") ) {
		printf("Vision Plus Remote Control Config\n"
			INFO"\n"
		       "vpcfg COMMAND [COMMAND_PARAMETER] [--dev device]\n"
		       "default device is "REMOTE_DEV"\n"
				 "commands: \n"
				 "\t0 -  CMD_DBG_ON\n"
				 "\t1 -  CMD_DBG_OFF\n"
				 "\t2 -  CMD_REMAP_ON\n"
				 "\t3 -  CMD_REMAP_OFF\n"
				 "\t4 -  CMD_EVENTS_ON\n"
				 "\t5 -  CMD_EVENTS_OFF\n"
				 "\t6 -  CMD_PRINT_INFO\n"
				 "\t7 -  CMD_RAISE_EVENT KEY_CODE\n"
				 "\t8 -  CMD_CLEAR_TABLE\n"
				 "\t9 -  CMD_LOCK_DEVICE\n"
				 "\t10 - CMD_UNLOCK_DEVICE\n"
		      );
		return 0;
	}
	if (argc > 1){
		int d = arg_num(argc, argv, "--dev");
		char *device;
		if ( d )
			device = argv[d + 1];
		else
			device = REMOTE_DEV;
		int dev = open(device, OPEN_FLAGS);
		if ( dev == -1 ) {
			fprintf(stderr, "error opening: %s, %s!\n", device, strerror(errno));
			return 3;
		}
		int idx = cmd_idx(argv[1]);
		if (idx==-1){ 
			fprintf(stderr, "Unknown command %s\n", argv[1]);
			return 1;
		}
		int ret = 0;
		if (idx == CMD_RAISE_EVENT){
			if (argc>2){
				int key=atoi(argv[2]);
				if ( ! (ret=vp_event(dev, key)) )
					fprintf(stderr, "vp_event() faild ( %d )! See dmesg\n", ret);	
			} else {
				fprintf(stderr, "Missing command parameter!\n");
				return 2;
			}
		} else {
			if ( ! (ret=vp_sendcmd(dev, idx)) )
				fprintf(stderr, "vp_sendcmd() faild ( %d )! See dmesg\n", ret);
		}
		close(dev);
	} else {
		printf("Use --help to see options\n");
		return 6;
	}
	return 0;	
}
